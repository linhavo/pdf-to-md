import subprocess
import sys
import time
from pathlib import Path

INPUT_DIR = Path("input")
OUTPUT_DIR = Path("output")
DONE_DIR = INPUT_DIR / "done"
POLL_INTERVAL = 3  # seconds


def convert(pdf_path: Path) -> None:
    print(f"Converting: {pdf_path.name} ...")
    result = subprocess.run(
        [sys.executable, "pdf-convertor-windows.py", str(pdf_path), "--image-output", "off"],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        print(f"  ERROR: {result.stderr.strip() or result.stdout.strip()}")
        return

    # pdf-convertor-windows.py writes to outputs/<parent>/, move result to OUTPUT_DIR
    generated = Path("outputs") / pdf_path.parent / (pdf_path.stem + ".md")
    if generated.exists():
        dest = OUTPUT_DIR / (pdf_path.stem + ".md")
        generated.replace(dest)
        print(f"  Done -> {dest}")
    else:
        print(f"  Warning: expected output not found at {generated}")

    # Move processed PDF to done/
    DONE_DIR.mkdir(parents=True, exist_ok=True)
    pdf_path.replace(DONE_DIR / pdf_path.name)


def main() -> None:
    INPUT_DIR.mkdir(exist_ok=True)
    OUTPUT_DIR.mkdir(exist_ok=True)

    print("Watching input/ for PDF files. Press Ctrl+C to stop.")
    print(f"  Drop PDFs into:      {INPUT_DIR.resolve()}")
    print(f"  Markdown appears in: {OUTPUT_DIR.resolve()}")
    print()

    seen: set[Path] = set()

    while True:
        pdfs = set(INPUT_DIR.glob("*.pdf"))
        new_pdfs = pdfs - seen

        for pdf in sorted(new_pdfs):
            # Wait until the file stops growing (i.e. copy is complete)
            prev_size = -1
            for _ in range(10):
                size = pdf.stat().st_size
                if size == prev_size:
                    break
                prev_size = size
                time.sleep(1)

            try:
                convert(pdf)
            except Exception as exc:
                print(f"  ERROR processing {pdf.name}: {exc}")

        seen = set(INPUT_DIR.glob("*.pdf"))
        time.sleep(POLL_INTERVAL)


if __name__ == "__main__":
    main()
