@echo off
title PDF Converter
echo ============================
echo       PDF Converter
echo ============================
echo.

:: ── First-time setup ────────────────────────────────────────────────────────

if not exist ".venv" (
    echo First run detected. Running setup...
    echo.

    java -version >nul 2>&1
    if errorlevel 1 (
        echo ERROR: Java is not installed.
        echo Please download and install OpenJDK from https://adoptium.net/
        echo Then run this file again.
        pause
        exit /b 1
    )

    echo Installing dependencies ^(this may take a minute^)...
    python -m venv .venv
    if errorlevel 1 (
        echo ERROR: Could not create virtual environment. Is Python installed?
        pause
        exit /b 1
    )
    .venv\Scripts\pip install -r requirements.txt
    if errorlevel 1 (
        echo ERROR: Dependency installation failed.
        pause
        exit /b 1
    )
    echo.
    echo Setup complete!
    echo.
)

:: ── Desktop shortcuts (offered once) ────────────────────────────────────────

if not exist ".shortcuts_created" (
    set /p CREATE_SHORTCUTS=Create desktop shortcuts to the input and output folders? [Y/N]:
    if /i "%CREATE_SHORTCUTS%"=="Y" (
        set DESKTOP=%USERPROFILE%\Desktop
        set HERE=%~dp0
        powershell -NoProfile -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut('%DESKTOP%\PDF Input.lnk');$s.TargetPath='%HERE%input';$s.Save()"
        powershell -NoProfile -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut('%DESKTOP%\PDF Output.lnk');$s.TargetPath='%HERE%output';$s.Save()"
        echo Shortcuts created on your Desktop.
    )
    echo. > .shortcuts_created
    echo.
)

:: ── Start watcher ────────────────────────────────────────────────────────────

echo Drop PDF files into the "input" folder.
echo Converted Markdown files will appear in the "output" folder.
echo You can minimise this window - it must stay open while converting.
echo.

.venv\Scripts\python watcher.py
pause
